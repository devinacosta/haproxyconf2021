require "fluent/plugin/parser"
require "base64"

module Fluent
  module Plugin
    class HaproxyParser < Parser
      Plugin.register_parser("haproxy", self)

      #REGEXP = /^(?<time>[^ ]*\s*[^ ]* [^ ]*) localhost (?<ps>\w+)\[(?<pid>\d+)\]: ((?<c_ip>[\w\.]+):(?<c_port>\d+) \[(?<hatime>.+)\] (?<f_end>[\w-]+)~ (?<b_end>[\w-.]+)\/(?<b_server>[\w-]+) (?<tq>\d+)\/(?<tw>\d+)\/(?<tc>\d+)\/(?<tr>\d+)\/(?<tt>\d+) (?<status_code>\d+) (?<bytes>\d+) (?<req_cookie>\S+) (?<res_cookie>\S+) (?<t_state>[\w-]+) (?<blocklist_reason>\w+) (?<actconn>\d+)\/(?<feconn>\d+)\/(?<beconn>\d+)\/(?<srv_conn>\d+)\/(?<retries>\d+) (?<srv_queue>\d+)\/(?<backend_queue>\d+) (?<sslver>\w+) \{?(?<req_headers>[^}]*)\}? ?\{?(?<res_headers>[^}]*)\}? ?"(?<request>[^"]*)"|(?<message>.+))/
      #REGEXP = /^(?<syslog_time>[^ ]* +[^ ]* +[^ ]*) (?<syslog_host>[\w\-\.]+) (?<ps>[\w-]+)\[(?<pid>\d+)\]: ((?<c_ip>[\w.]+):(?<c_port>\d+) \[(?<ctime>.+)\] (?<f_end>[\w_.~]+) (?<b_end>[\w_.]+)\/(?<b_server>[\w<>]+) (?<tq>[\d\-]+)\/(?<tw>[\d\-]+)\/(?<tc>[\d\-]+)\/(?<tr>[\d\-]+)\/(?<tt>[\d\-]+) (?<status_code>\d+) (?<bytes>\d+) (?<req_cookie>\S?) (?<res_cookie>\S?) (?<t_state>[\w\-]+) (?<blockedreason>[\w_=]+) (?<actconn>\d+)\/(?<feconn>\d+)\/(?<beconn>\d+)\/(?<srv_conn>\d+)\/(?<retries>\d+) (?<srv_queue>\d+)\/(?<backend_queue>\d+) (?<tlsver>[\S]+)\{?(?<req_headers>[^}"]*)\}?  ?"(?<request>[^"]*).*|((\[(?<message_level>[^\]]+)\] )?(?<message>.+)))/
      #REGEXP = /^(?<syslog_time>[^ ]* +[^ ]* +[^ ]*) (?<syslog_host>[\w\-\.]+) (?<ps>[\w-]+)\[(?<pid>\d+)\]: ((?<c_ip>[\w.]+):(?<c_port>\d+) \[(?<ctime>.+)\] (?<f_end>[\w_.]+) (?<b_end>[\w_.]+)\/(?<b_server>[\w<>]+) (?<tq>[\d\-]+)\/(?<tw>[\d\-]+)\/(?<tc>[\d\-]+)\/(?<tr>[\d\-]+)\/(?<tt>[\d\-]+) (?<status_code>\d+) (?<bytes>\d+) (?<req_cookie>\S?) (?<res_cookie>\S?) (?<t_state>[\w\-]+) (?<blockedreason>[\w_]+) (?<actconn>\d+)\/(?<feconn>\d+)\/(?<beconn>\d+)\/(?<srv_conn>\d+)\/(?<retries>\d+) (?<srv_queue>\d+)\/(?<backend_queue>\d+) (?<tlsver>[\S]+)\{?(?<req_headers>[^"]*)\}? ?"(?<request>[^"]*).*|(?<message>.+))/
      REGEXP = /^(?<syslog_time>[^ ]* +[^ ]* +[^ ]*) (?<syslog_host>[\w\-\.]+) (?<ps>[\w-]+)\[(?<pid>\d+)\]: ((?<c_ip>[\w.]+):(?<c_port>\d+) \[(?<ctime>.+)\] (?<frontend>[^ ]+) (?<backend>[^ ]+)?\/(?<backend_server>[^ ]+) (?<tr_receive_time>[^\/]+)\/(?<tw_queue_time>[^ ]+)\/(?<tc_connect_time>[^ ]+)\/(?<tr_resp_time>[^ ]+)\/(?<ta_active_time>[^ ]+) (?<status_code>\d+) (?<bytes_read>\d+) (?<req_cookie>[^ ]+) (?<res_cookie>[^ ]+) (?<term_state>[\w-]+) (?<blockedreason>[^ ]+) (?<actconn>\d+)\/(?<feconn>\d+)\/(?<beconn>\d+)\/(?<srv_conn>\d+)\/(?<retries>\d+) (?<srv_queue>\d+)\/(?<backend_queue>\d+) (?<tlsver>[\S]+) \{?(?<req_headers>[^}]*)\}? ?"(?<request>[^\"]*)"|(?<message>.+))/

      config_param :headers, :array, default: []

      def configure(conf)
        super
      end

      def parse(text)
        m = REGEXP.match(text)
        unless m
          yield nil, nil
          return
        end

        r = {}
        m.names.each do |name|
          if value = m[name]
            r[name] = value
          end
        end

        # request
        if r["request"]
          request = r["request"].split(" ")
          r.delete("request")
          uri = request[1].split("?")
          r["method"] = request[0]
          r["path"] = uri[0]
          r["query_string"] ||= uri[1]
          r["http_version"] = request[2]
        end

        # headers
        if r["req_headers"]
          parsed_headers = r["req_headers"].split("|")
          r.delete("req_headers")
          parsed_headers.each_with_index do |header, index|
            if not @headers.empty?
              r[@headers[index]] = header
            end
          end
          if r["auth"]
            type = r["auth"].split(" ")[0]
            cred = r["auth"].split(" ")[1]
            r.delete("auth")
            r["auth_type"] = type
            if type == "Basic"
              r["user"] = Base64.decode64(cred).split(":")[0]
            end
          end
        end

        time, record = convert_values(parse_time(r), r)
        yield time, record
      end
    end
  end
end
